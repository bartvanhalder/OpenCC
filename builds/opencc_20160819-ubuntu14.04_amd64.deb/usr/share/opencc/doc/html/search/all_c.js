var searchData=
[
  ['newfromdict',['NewFromDict',['../classopencc_1_1_darts_dict.html#a02dbb1e284cb99dfeb4c8cc5bd997d28',1,'opencc::DartsDict::NewFromDict()'],['../classopencc_1_1_text_dict.html#af593a95f96c060a45eb6062d27ca27e9',1,'opencc::TextDict::NewFromDict()']]],
  ['nextchar',['NextChar',['../classopencc_1_1_u_t_f8_util.html#ae26e05a30598021e204448ea71971208',1,'opencc::UTF8Util']]],
  ['nextcharlength',['NextCharLength',['../classopencc_1_1_u_t_f8_util.html#ae71013ee7dfef2aba9e99dbae8f24bbd',1,'opencc::UTF8Util']]],
  ['nextcharlengthnoexception',['NextCharLengthNoException',['../classopencc_1_1_u_t_f8_util.html#a7741e8ca4c6ad9e4f68b9d4633b58def',1,'opencc::UTF8Util']]],
  ['notshorterthan',['NotShorterThan',['../classopencc_1_1_u_t_f8_util.html#a8ee1ac13118c59a357114782d18a3497',1,'opencc::UTF8Util']]],
  ['novaluedictentry',['NoValueDictEntry',['../classopencc_1_1_no_value_dict_entry.html',1,'opencc']]],
  ['null',['Null',['../classopencc_1_1_optional.html#a5a11611ae7d3e677a6c0a611c06d9e3d',1,'opencc::Optional']]]
];
