var searchData=
[
  ['filenotfound',['FileNotFound',['../classopencc_1_1_file_not_found.html',1,'opencc']]],
  ['filenotwritable',['FileNotWritable',['../classopencc_1_1_file_not_writable.html',1,'opencc']]],
  ['findnextinline',['FindNextInline',['../classopencc_1_1_u_t_f8_util.html#a3c9791916dd617caa7eef44a67900c20',1,'opencc::UTF8Util']]],
  ['fromsubstr',['FromSubstr',['../classopencc_1_1_u_t_f8_util.html#afefc07b662cd10ebe998685e2ce3b72d',1,'opencc::UTF8Util']]]
];
