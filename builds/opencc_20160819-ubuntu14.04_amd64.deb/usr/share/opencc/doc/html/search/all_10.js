var searchData=
[
  ['segmentation',['Segmentation',['../classopencc_1_1_segmentation.html',1,'opencc']]],
  ['segments',['Segments',['../classopencc_1_1_segments.html',1,'opencc']]],
  ['serializabledict',['SerializableDict',['../classopencc_1_1_serializable_dict.html',1,'opencc']]],
  ['serializetofile',['SerializeToFile',['../classopencc_1_1_binary_dict.html#a9e093cca8aa09b56acc1b748d04570c7',1,'opencc::BinaryDict::SerializeToFile()'],['../classopencc_1_1_darts_dict.html#a2260d02ef4c50752bffbc4c8894ecba2',1,'opencc::DartsDict::SerializeToFile()'],['../classopencc_1_1_serializable_dict.html#acb184b20e1f9eaee02905809cf259e5f',1,'opencc::SerializableDict::SerializeToFile(FILE *fp) const =0'],['../classopencc_1_1_serializable_dict.html#aa60ae8e8b708e94b9d613335b3d52772',1,'opencc::SerializableDict::SerializeToFile(const string &amp;fileName) const '],['../classopencc_1_1_text_dict.html#a5f553c78a51026e7c0c7228cb372d589',1,'opencc::TextDict::SerializeToFile()']]],
  ['shouldnotbehere',['ShouldNotBeHere',['../classopencc_1_1_should_not_be_here.html',1,'opencc']]],
  ['signals',['Signals',['../structopencc_1_1_phrase_extract_1_1_signals.html',1,'opencc::PhraseExtract']]],
  ['simpleconverter',['SimpleConverter',['../classopencc_1_1_simple_converter.html#a6e18e21f772ed986fb5ff89f6576dad4',1,'opencc::SimpleConverter']]],
  ['simpleconverter',['SimpleConverter',['../classopencc_1_1_simple_converter.html',1,'opencc']]],
  ['singlevaluedictentry',['SingleValueDictEntry',['../classopencc_1_1_single_value_dict_entry.html',1,'opencc']]],
  ['skiputf8bom',['SkipUtf8Bom',['../classopencc_1_1_u_t_f8_util.html#a2c755b77ec792c825880b07c8ec2f788',1,'opencc::UTF8Util']]],
  ['strmultivaluedictentry',['StrMultiValueDictEntry',['../classopencc_1_1_str_multi_value_dict_entry.html',1,'opencc']]],
  ['strsinglevaluedictentry',['StrSingleValueDictEntry',['../classopencc_1_1_str_single_value_dict_entry.html',1,'opencc']]]
];
