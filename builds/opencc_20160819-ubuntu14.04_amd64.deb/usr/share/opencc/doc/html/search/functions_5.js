var searchData=
[
  ['keymaxlength',['KeyMaxLength',['../classopencc_1_1_darts_dict.html#a838b45eb4b44dafd218a79e653643458',1,'opencc::DartsDict::KeyMaxLength()'],['../classopencc_1_1_dict.html#a3510da98594e790c35e5b06198d99ff7',1,'opencc::Dict::KeyMaxLength()'],['../classopencc_1_1_dict_group.html#a5bc0ea96b6ee25407c0fa91e5745126e',1,'opencc::DictGroup::KeyMaxLength()'],['../classopencc_1_1_text_dict.html#aefb0f7f3a50e46caa48d38a74a642ce5',1,'opencc::TextDict::KeyMaxLength()']]]
];
