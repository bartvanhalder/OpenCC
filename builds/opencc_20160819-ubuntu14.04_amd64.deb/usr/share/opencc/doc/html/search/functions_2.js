var searchData=
[
  ['get',['Get',['../classopencc_1_1_optional.html#ab9556955d60216604b62c9c26d53f1f4',1,'opencc::Optional']]],
  ['getlexicon',['GetLexicon',['../classopencc_1_1_darts_dict.html#ac8a596805a820406753f475a90395e86',1,'opencc::DartsDict::GetLexicon()'],['../classopencc_1_1_dict.html#a5c7c7bb2a5c9fca9077233bd38d7a3dd',1,'opencc::Dict::GetLexicon()'],['../classopencc_1_1_dict_group.html#a664f597efe686d1d96391cac0936f343',1,'opencc::DictGroup::GetLexicon()'],['../classopencc_1_1_text_dict.html#a4d82f1923f2f9b9ce47ea0aed84414cc',1,'opencc::TextDict::GetLexicon()']]]
];
