var searchData=
[
  ['utf8stringslicebase',['UTF8StringSliceBase',['../classopencc_1_1_u_t_f8_string_slice_base.html',1,'opencc']]],
  ['utf8stringslicebase_3c_20size_5ft_20_3e',['UTF8StringSliceBase&lt; size_t &gt;',['../classopencc_1_1_u_t_f8_string_slice_base.html',1,'opencc']]],
  ['utf8util',['UTF8Util',['../classopencc_1_1_u_t_f8_util.html',1,'opencc']]]
];
