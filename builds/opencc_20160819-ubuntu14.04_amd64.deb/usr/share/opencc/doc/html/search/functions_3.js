var searchData=
[
  ['islineendingorfileending',['IsLineEndingOrFileEnding',['../classopencc_1_1_u_t_f8_util.html#a008b85311545f43a7a3c14e304004266',1,'opencc::UTF8Util']]],
  ['isnull',['IsNull',['../classopencc_1_1_optional.html#a2b9ae52c50a94abc39593085e02f0d50',1,'opencc::Optional']]]
];
